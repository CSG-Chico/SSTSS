﻿namespace SSTSv2
{
    partial class Mainpanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("BSCS1");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Year 1", new System.Windows.Forms.TreeNode[] {
            treeNode1});
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("BSCS2");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Year 2", new System.Windows.Forms.TreeNode[] {
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("BSCS3");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Year 3", new System.Windows.Forms.TreeNode[] {
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("BSCS4");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Year 4", new System.Windows.Forms.TreeNode[] {
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Computer Science", new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode4,
            treeNode6,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("BSIT1 A");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("BSIT1 B");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("BSIT1 C");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("BSIT1 D");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Year1", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("BSIT2 A");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("BSIT2 B");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("BSIT2 C");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Year2", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16,
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("BSIT3 A");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Year3", new System.Windows.Forms.TreeNode[] {
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("BSIT4 A");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("BSIT4 B");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Year4", new System.Windows.Forms.TreeNode[] {
            treeNode21,
            treeNode22});
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Information Technology", new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode18,
            treeNode20,
            treeNode23});
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("ComTech1 A");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("ComTech1 B");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("ComTech1 C");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("ComTech1 D");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Year1", new System.Windows.Forms.TreeNode[] {
            treeNode25,
            treeNode26,
            treeNode27,
            treeNode28});
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("ComTech2 A");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("ComTech2 B");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("ComTech2 C");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Year2", new System.Windows.Forms.TreeNode[] {
            treeNode30,
            treeNode31,
            treeNode32});
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Computer Technology", new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode33});
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("BLIS1");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Year1", new System.Windows.Forms.TreeNode[] {
            treeNode35});
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("BLIS2");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Year2", new System.Windows.Forms.TreeNode[] {
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Library and Information Systems", new System.Windows.Forms.TreeNode[] {
            treeNode36,
            treeNode38});
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Courses", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode24,
            treeNode34,
            treeNode39});
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Paraluman Maria Fatima B. Pecito");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Daryl V. Buen");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Maribel T. Tacla");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Rossane S. Agup");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Richard C. Arruejo");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Honey Girl A. Avo");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Peter R. Rabanal");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("June Leonel M. Ngayaan");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Jennyfer D. Alasaas");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Noel S. Rafanan");
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("Angelito T. Ramos");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("Caren Kate T. Quitoriano");
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("Fernandino S. Perilla");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("Rogelio R. Rabena");
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("Leo Angelou B. Baja");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("Leilani A. Basa");
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("Harold L. Costales");
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("Mariano T. Romano Jr.");
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("Esteban H. Fabro");
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Joel S. Morales");
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("Bryan S. Lamarca");
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("Instructors", new System.Windows.Forms.TreeNode[] {
            treeNode41,
            treeNode42,
            treeNode43,
            treeNode44,
            treeNode45,
            treeNode46,
            treeNode47,
            treeNode48,
            treeNode49,
            treeNode50,
            treeNode51,
            treeNode52,
            treeNode53,
            treeNode54,
            treeNode55,
            treeNode56,
            treeNode57,
            treeNode58,
            treeNode59,
            treeNode60,
            treeNode61});
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("CC101");
            System.Windows.Forms.TreeNode treeNode64 = new System.Windows.Forms.TreeNode("CC102");
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("CC104");
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("CC105");
            System.Windows.Forms.TreeNode treeNode67 = new System.Windows.Forms.TreeNode("CC201");
            System.Windows.Forms.TreeNode treeNode68 = new System.Windows.Forms.TreeNode("CC202");
            System.Windows.Forms.TreeNode treeNode69 = new System.Windows.Forms.TreeNode("CC203");
            System.Windows.Forms.TreeNode treeNode70 = new System.Windows.Forms.TreeNode("CC204");
            System.Windows.Forms.TreeNode treeNode71 = new System.Windows.Forms.TreeNode("CC205");
            System.Windows.Forms.TreeNode treeNode72 = new System.Windows.Forms.TreeNode("CC206");
            System.Windows.Forms.TreeNode treeNode73 = new System.Windows.Forms.TreeNode("IAC");
            System.Windows.Forms.TreeNode treeNode74 = new System.Windows.Forms.TreeNode("Rooms", new System.Windows.Forms.TreeNode[] {
            treeNode63,
            treeNode64,
            treeNode65,
            treeNode66,
            treeNode67,
            treeNode68,
            treeNode69,
            treeNode70,
            treeNode71,
            treeNode72,
            treeNode73});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainpanel));
            this.gunaShadowPanel1 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaShadowPanel2 = new Guna.UI.WinForms.GunaShadowPanel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaAdvenceTileButton2 = new Guna.UI.WinForms.GunaAdvenceTileButton();
            this.coursemainbotton = new Guna.UI.WinForms.GunaAdvenceTileButton();
            this.gunaAdvenceTileButton1 = new Guna.UI.WinForms.GunaAdvenceTileButton();
            this.gunaShadowPanel3 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaShadowPanel4 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaShadowPanel1.SuspendLayout();
            this.gunaShadowPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gunaShadowPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaShadowPanel1
            // 
            this.gunaShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel1.BaseColor = System.Drawing.Color.Fuchsia;
            this.gunaShadowPanel1.Controls.Add(this.gunaPanel1);
            this.gunaShadowPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaShadowPanel1.Location = new System.Drawing.Point(0, 0);
            this.gunaShadowPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.gunaShadowPanel1.Name = "gunaShadowPanel1";
            this.gunaShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel1.ShadowDepth = 20;
            this.gunaShadowPanel1.ShadowShift = 1;
            this.gunaShadowPanel1.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped;
            this.gunaShadowPanel1.Size = new System.Drawing.Size(1370, 58);
            this.gunaShadowPanel1.TabIndex = 0;
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.White;
            this.gunaPanel1.ForeColor = System.Drawing.Color.Aqua;
            this.gunaPanel1.Location = new System.Drawing.Point(255, 58);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(200, 200);
            this.gunaPanel1.TabIndex = 2;
            // 
            // gunaShadowPanel2
            // 
            this.gunaShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.gunaShadowPanel2.Controls.Add(this.treeView1);
            this.gunaShadowPanel2.Controls.Add(this.panel1);
            this.gunaShadowPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaShadowPanel2.Location = new System.Drawing.Point(0, 58);
            this.gunaShadowPanel2.Name = "gunaShadowPanel2";
            this.gunaShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel2.ShadowDepth = 5;
            this.gunaShadowPanel2.ShadowShift = 1;
            this.gunaShadowPanel2.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel2.Size = new System.Drawing.Size(291, 691);
            this.gunaShadowPanel2.TabIndex = 1;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 63);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "BSCS1";
            treeNode1.Text = "BSCS1";
            treeNode2.Name = "CSYear1";
            treeNode2.Text = "Year 1";
            treeNode3.Name = "BSCS2";
            treeNode3.Text = "BSCS2";
            treeNode4.Name = "CSYear2";
            treeNode4.Text = "Year 2";
            treeNode5.Name = "BSCS3";
            treeNode5.Text = "BSCS3";
            treeNode6.Name = "CSYear3";
            treeNode6.Text = "Year 3";
            treeNode7.Name = "BSCS4";
            treeNode7.Text = "BSCS4";
            treeNode8.Name = "CSYear4";
            treeNode8.Text = "Year 4";
            treeNode9.Name = "CS";
            treeNode9.Text = "Computer Science";
            treeNode10.Name = "BSIT1 A";
            treeNode10.Text = "BSIT1 A";
            treeNode11.Name = "BSIT1 B";
            treeNode11.Text = "BSIT1 B";
            treeNode12.Name = "BSIT1 C";
            treeNode12.Text = "BSIT1 C";
            treeNode13.Name = "BSIT1 D";
            treeNode13.Text = "BSIT1 D";
            treeNode14.Name = "Year1";
            treeNode14.Text = "Year1";
            treeNode15.Name = "BSIT2 A";
            treeNode15.Text = "BSIT2 A";
            treeNode16.Name = "BSIT2 B";
            treeNode16.Text = "BSIT2 B";
            treeNode17.Name = "BSIT2 C";
            treeNode17.Text = "BSIT2 C";
            treeNode18.Name = "Year2";
            treeNode18.Text = "Year2";
            treeNode19.Name = "BSIT3 A";
            treeNode19.Text = "BSIT3 A";
            treeNode20.Name = "Year3";
            treeNode20.Text = "Year3";
            treeNode21.Name = "BSIT4 A";
            treeNode21.Text = "BSIT4 A";
            treeNode22.Name = "BSIT4 B";
            treeNode22.Text = "BSIT4 B";
            treeNode23.Name = "Year4";
            treeNode23.Text = "Year4";
            treeNode24.Name = "IT";
            treeNode24.Text = "Information Technology";
            treeNode25.Name = "ComTech1 A";
            treeNode25.Text = "ComTech1 A";
            treeNode26.Name = "ComTech1 B";
            treeNode26.Text = "ComTech1 B";
            treeNode27.Name = "ComTech1 C";
            treeNode27.Text = "ComTech1 C";
            treeNode28.Name = "ComTech1 D";
            treeNode28.Text = "ComTech1 D";
            treeNode29.Name = "Year1";
            treeNode29.Text = "Year1";
            treeNode30.Name = "ComTech2 A";
            treeNode30.Text = "ComTech2 A";
            treeNode31.Name = "ComTech2 B";
            treeNode31.Text = "ComTech2 B";
            treeNode32.Name = "ComTech2 C";
            treeNode32.Text = "ComTech2 C";
            treeNode33.Name = "Year2";
            treeNode33.Text = "Year2";
            treeNode34.Name = "ComTech";
            treeNode34.Text = "Computer Technology";
            treeNode35.Name = "BLIS1";
            treeNode35.Text = "BLIS1";
            treeNode36.Name = "Year1";
            treeNode36.Text = "Year1";
            treeNode37.Name = "BLIS2";
            treeNode37.Text = "BLIS2";
            treeNode38.Name = "Year2";
            treeNode38.Text = "Year2";
            treeNode39.Name = "LiS";
            treeNode39.Text = "Library and Information Systems";
            treeNode40.Name = "Courses";
            treeNode40.Text = "Courses";
            treeNode41.Name = "Paraluman Maria Fatima B. Pecito";
            treeNode41.Text = "Paraluman Maria Fatima B. Pecito";
            treeNode42.Name = "Daryl V. Buen";
            treeNode42.Text = "Daryl V. Buen";
            treeNode43.Name = "Maribel T. Tacla";
            treeNode43.Text = "Maribel T. Tacla";
            treeNode44.Name = "Rossane S. Agup";
            treeNode44.Text = "Rossane S. Agup";
            treeNode45.Name = "Richard C. Arruejo";
            treeNode45.Text = "Richard C. Arruejo";
            treeNode46.Name = "Honey Girl A. Avo";
            treeNode46.Text = "Honey Girl A. Avo";
            treeNode47.Name = "Peter R. Rabanal";
            treeNode47.Text = "Peter R. Rabanal";
            treeNode48.Name = "June Leonel M. Ngayaan";
            treeNode48.Text = "June Leonel M. Ngayaan";
            treeNode49.Name = "Jennyfer D. Alasaas";
            treeNode49.Text = "Jennyfer D. Alasaas";
            treeNode50.Name = "Noel S. Rafanan";
            treeNode50.Text = "Noel S. Rafanan";
            treeNode51.Name = "Angelito T. Ramos";
            treeNode51.Text = "Angelito T. Ramos";
            treeNode52.Name = "Caren Kate T. Quitoriano";
            treeNode52.Text = "Caren Kate T. Quitoriano";
            treeNode53.Name = "Fernandino S. Perilla";
            treeNode53.Text = "Fernandino S. Perilla";
            treeNode54.Name = "Rogelio R. Rabena";
            treeNode54.Text = "Rogelio R. Rabena";
            treeNode55.Name = "Leo Angelou B. Baja";
            treeNode55.Text = "Leo Angelou B. Baja";
            treeNode56.Name = "Leilani A. Basa";
            treeNode56.Text = "Leilani A. Basa";
            treeNode57.Name = "Harold L. Costales";
            treeNode57.Text = "Harold L. Costales";
            treeNode58.Name = "Mariano T. Romano Jr.";
            treeNode58.Text = "Mariano T. Romano Jr.";
            treeNode59.Name = "Esteban H. Fabro";
            treeNode59.Text = "Esteban H. Fabro";
            treeNode60.Name = "Joel S. Morales";
            treeNode60.Text = "Joel S. Morales";
            treeNode61.Name = "Bryan S. Lamarca";
            treeNode61.Text = "Bryan S. Lamarca";
            treeNode62.Name = "Instructors";
            treeNode62.Text = "Instructors";
            treeNode63.Name = "CC101";
            treeNode63.Text = "CC101";
            treeNode64.Name = "CC102";
            treeNode64.Text = "CC102";
            treeNode65.Name = "CC104";
            treeNode65.Text = "CC104";
            treeNode66.Name = "CC105";
            treeNode66.Text = "CC105";
            treeNode67.Name = "CC201";
            treeNode67.Text = "CC201";
            treeNode68.Name = "CC202";
            treeNode68.Text = "CC202";
            treeNode69.Name = "CC203";
            treeNode69.Text = "CC203";
            treeNode70.Name = "CC204";
            treeNode70.Text = "CC204";
            treeNode71.Name = "CC205";
            treeNode71.Text = "CC205";
            treeNode72.Name = "CC206";
            treeNode72.Text = "CC206";
            treeNode73.Name = "IAC";
            treeNode73.Text = "IAC";
            treeNode74.Name = "Rooms";
            treeNode74.Text = "Rooms";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode40,
            treeNode62,
            treeNode74});
            this.treeView1.Size = new System.Drawing.Size(291, 628);
            this.treeView1.TabIndex = 4;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel1.Controls.Add(this.gunaAdvenceTileButton2);
            this.panel1.Controls.Add(this.coursemainbotton);
            this.panel1.Controls.Add(this.gunaAdvenceTileButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(291, 63);
            this.panel1.TabIndex = 3;
            // 
            // gunaAdvenceTileButton2
            // 
            this.gunaAdvenceTileButton2.Animated = true;
            this.gunaAdvenceTileButton2.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceTileButton2.AnimationSpeed = 0.03F;
            this.gunaAdvenceTileButton2.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceTileButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton2.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceTileButton2.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton2.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceTileButton2.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceTileButton2.CheckedImage")));
            this.gunaAdvenceTileButton2.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceTileButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceTileButton2.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaAdvenceTileButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceTileButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceTileButton2.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceTileButton2.Image")));
            this.gunaAdvenceTileButton2.ImageSize = new System.Drawing.Size(26, 26);
            this.gunaAdvenceTileButton2.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceTileButton2.Location = new System.Drawing.Point(194, 0);
            this.gunaAdvenceTileButton2.Name = "gunaAdvenceTileButton2";
            this.gunaAdvenceTileButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.gunaAdvenceTileButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton2.OnHoverForeColor = System.Drawing.Color.Fuchsia;
            this.gunaAdvenceTileButton2.OnHoverImage = null;
            this.gunaAdvenceTileButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.gunaAdvenceTileButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton2.Size = new System.Drawing.Size(97, 63);
            this.gunaAdvenceTileButton2.TabIndex = 2;
            this.gunaAdvenceTileButton2.Text = "Room";
            this.gunaAdvenceTileButton2.Click += new System.EventHandler(this.gunaAdvenceTileButton2_Click);
            // 
            // coursemainbotton
            // 
            this.coursemainbotton.Animated = true;
            this.coursemainbotton.AnimationHoverSpeed = 0.07F;
            this.coursemainbotton.AnimationSpeed = 0.03F;
            this.coursemainbotton.BaseColor = System.Drawing.Color.Transparent;
            this.coursemainbotton.BorderColor = System.Drawing.Color.Black;
            this.coursemainbotton.CheckedBaseColor = System.Drawing.Color.Gray;
            this.coursemainbotton.CheckedBorderColor = System.Drawing.Color.Black;
            this.coursemainbotton.CheckedForeColor = System.Drawing.Color.White;
            this.coursemainbotton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("coursemainbotton.CheckedImage")));
            this.coursemainbotton.CheckedLineColor = System.Drawing.Color.DimGray;
            this.coursemainbotton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.coursemainbotton.Dock = System.Windows.Forms.DockStyle.Left;
            this.coursemainbotton.FocusedColor = System.Drawing.Color.Empty;
            this.coursemainbotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coursemainbotton.ForeColor = System.Drawing.Color.White;
            this.coursemainbotton.Image = global::SSTSv2.Properties.Resources.student_male_300px;
            this.coursemainbotton.ImageSize = new System.Drawing.Size(25, 25);
            this.coursemainbotton.LineColor = System.Drawing.Color.Transparent;
            this.coursemainbotton.Location = new System.Drawing.Point(97, 0);
            this.coursemainbotton.Name = "coursemainbotton";
            this.coursemainbotton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.coursemainbotton.OnHoverBorderColor = System.Drawing.Color.Black;
            this.coursemainbotton.OnHoverForeColor = System.Drawing.Color.Fuchsia;
            this.coursemainbotton.OnHoverImage = null;
            this.coursemainbotton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.coursemainbotton.OnPressedColor = System.Drawing.Color.Black;
            this.coursemainbotton.Size = new System.Drawing.Size(91, 63);
            this.coursemainbotton.TabIndex = 0;
            this.coursemainbotton.Text = "Instructor";
            // 
            // gunaAdvenceTileButton1
            // 
            this.gunaAdvenceTileButton1.Animated = true;
            this.gunaAdvenceTileButton1.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceTileButton1.AnimationSpeed = 0.03F;
            this.gunaAdvenceTileButton1.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceTileButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton1.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceTileButton1.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton1.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceTileButton1.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceTileButton1.CheckedImage")));
            this.gunaAdvenceTileButton1.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceTileButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceTileButton1.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaAdvenceTileButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceTileButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceTileButton1.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceTileButton1.Image")));
            this.gunaAdvenceTileButton1.ImageSize = new System.Drawing.Size(26, 26);
            this.gunaAdvenceTileButton1.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceTileButton1.Location = new System.Drawing.Point(0, 0);
            this.gunaAdvenceTileButton1.Name = "gunaAdvenceTileButton1";
            this.gunaAdvenceTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.gunaAdvenceTileButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton1.OnHoverForeColor = System.Drawing.Color.Fuchsia;
            this.gunaAdvenceTileButton1.OnHoverImage = null;
            this.gunaAdvenceTileButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceTileButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceTileButton1.Size = new System.Drawing.Size(97, 63);
            this.gunaAdvenceTileButton1.TabIndex = 1;
            this.gunaAdvenceTileButton1.Text = "Course";
            // 
            // gunaShadowPanel3
            // 
            this.gunaShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(86)))), ((int)(((byte)(86)))));
            this.gunaShadowPanel3.Controls.Add(this.gunaShadowPanel4);
            this.gunaShadowPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gunaShadowPanel3.Location = new System.Drawing.Point(291, 58);
            this.gunaShadowPanel3.Name = "gunaShadowPanel3";
            this.gunaShadowPanel3.Radius = 20;
            this.gunaShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel3.ShadowDepth = 20;
            this.gunaShadowPanel3.ShadowShift = 2;
            this.gunaShadowPanel3.Size = new System.Drawing.Size(1079, 691);
            this.gunaShadowPanel3.TabIndex = 2;
            this.gunaShadowPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.gunaShadowPanel3_Paint);
            // 
            // gunaShadowPanel4
            // 
            this.gunaShadowPanel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.gunaShadowPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaShadowPanel4.Location = new System.Drawing.Point(0, 0);
            this.gunaShadowPanel4.Name = "gunaShadowPanel4";
            this.gunaShadowPanel4.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel4.ShadowDepth = 5;
            this.gunaShadowPanel4.ShadowShift = 2;
            this.gunaShadowPanel4.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped;
            this.gunaShadowPanel4.Size = new System.Drawing.Size(1079, 67);
            this.gunaShadowPanel4.TabIndex = 0;
            // 
            // Mainpanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.gunaShadowPanel3);
            this.Controls.Add(this.gunaShadowPanel2);
            this.Controls.Add(this.gunaShadowPanel1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Mainpanel";
            this.Opacity = 0.97D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scheduling System";
            this.Load += new System.EventHandler(this.Mainpanel_Load);
            this.gunaShadowPanel1.ResumeLayout(false);
            this.gunaShadowPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.gunaShadowPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel2;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel3;
        private Guna.UI.WinForms.GunaAdvenceTileButton coursemainbotton;
        private Guna.UI.WinForms.GunaAdvenceTileButton gunaAdvenceTileButton2;
        private Guna.UI.WinForms.GunaAdvenceTileButton gunaAdvenceTileButton1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel4;
        private System.Windows.Forms.TreeView treeView1;
    }
}

