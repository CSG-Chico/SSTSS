﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SSTSv2
{
    public partial class Mainpanel : Form
    {
        public Mainpanel()
        {
            InitializeComponent();
        }

        private void Mainpanel_Load(object sender, EventArgs e)
        {

        }

        private void gunaShadowPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gunaAdvenceTileButton2_Click(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
