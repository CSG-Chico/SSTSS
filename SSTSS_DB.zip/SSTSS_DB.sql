-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.18 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for sstss_data
CREATE DATABASE IF NOT EXISTS `sstss_data` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `sstss_data`;

-- Dumping structure for table sstss_data.tbl_class
CREATE TABLE IF NOT EXISTS `tbl_class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_day` int(11) NOT NULL,
  `panel_name` varchar(50) NOT NULL,
  `fk_subject` varchar(50) NOT NULL,
  `fk_instructor` int(11) NOT NULL,
  `fk_time` int(11) NOT NULL,
  `fk_etime` int(11) NOT NULL,
  `fk_room` int(11) NOT NULL,
  PRIMARY KEY (`fk_time`,`fk_room`,`fk_day`) USING BTREE,
  UNIQUE KEY `panel_name` (`panel_name`),
  KEY `tbl_class_fk_subject` (`fk_subject`),
  KEY `tbl_class_fk_instructor` (`fk_instructor`),
  KEY `tbl_class_fk_room` (`fk_room`),
  KEY `tbl_class_fk_time` (`fk_time`),
  KEY `tbl_day_fk_day` (`fk_day`),
  KEY `class_id` (`class_id`),
  KEY `tbl_day_fk_etime` (`fk_etime`),
  CONSTRAINT `tbL_class_fk_section` FOREIGN KEY (`class_id`) REFERENCES `tbl_section` (`section_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_class_fk_instructor` FOREIGN KEY (`fk_instructor`) REFERENCES `tbl_instrctr` (`instructor_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_class_fk_room` FOREIGN KEY (`fk_room`) REFERENCES `tbl_room` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_class_fk_subject` FOREIGN KEY (`fk_subject`) REFERENCES `tbl_subject` (`subject_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_class_fk_time` FOREIGN KEY (`fk_time`) REFERENCES `tbl_time` (`time_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_day_fk_day` FOREIGN KEY (`fk_day`) REFERENCES `tbl_day` (`day_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_day_fk_etime` FOREIGN KEY (`fk_etime`) REFERENCES `tbl_time` (`time_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_class: ~1 rows (approximately)
DELETE FROM `tbl_class`;
/*!40000 ALTER TABLE `tbl_class` DISABLE KEYS */;
INSERT INTO `tbl_class` (`class_id`, `fk_day`, `panel_name`, `fk_subject`, `fk_instructor`, `fk_time`, `fk_etime`, `fk_room`) VALUES
	(2, 1, 'BSCS 2_Monday_0', 'CC102', 10, 7, 12, 2),
	(2, 1, 'BSCS 2_Monday_2', 'CC103', 10, 21, 24, 4);
/*!40000 ALTER TABLE `tbl_class` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_cllge
CREATE TABLE IF NOT EXISTS `tbl_cllge` (
  `college_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT 'college name',
  PRIMARY KEY (`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_cllge: ~0 rows (approximately)
DELETE FROM `tbl_cllge`;
/*!40000 ALTER TABLE `tbl_cllge` DISABLE KEYS */;
INSERT INTO `tbl_cllge` (`college_id`, `description`) VALUES
	(1, 'College of Communication and Information Technology');
/*!40000 ALTER TABLE `tbl_cllge` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_course
CREATE TABLE IF NOT EXISTS `tbl_course` (
  `cource_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `fk_college` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cource_id`,`fk_college`),
  KEY `tbl_course_fk_college` (`fk_college`),
  CONSTRAINT `tbl_course_fk_college` FOREIGN KEY (`fk_college`) REFERENCES `tbl_cllge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_course: ~4 rows (approximately)
DELETE FROM `tbl_course`;
/*!40000 ALTER TABLE `tbl_course` DISABLE KEYS */;
INSERT INTO `tbl_course` (`cource_id`, `description`, `fk_college`) VALUES
	(1, 'Bachelors of Science in Computer Science', 1),
	(2, 'Bachelors of Science in Information Technology', 1),
	(3, 'Bachelors in Library and Information Science', 1),
	(4, 'Diploma in Computer Technology', 1);
/*!40000 ALTER TABLE `tbl_course` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_day
CREATE TABLE IF NOT EXISTS `tbl_day` (
  `day_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) NOT NULL,
  PRIMARY KEY (`day_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_day: ~6 rows (approximately)
DELETE FROM `tbl_day`;
/*!40000 ALTER TABLE `tbl_day` DISABLE KEYS */;
INSERT INTO `tbl_day` (`day_id`, `description`) VALUES
	(1, 'Monday'),
	(2, 'Tuesday'),
	(3, 'Wednesday'),
	(4, 'Thursday'),
	(5, 'Friday'),
	(6, 'Saturday');
/*!40000 ALTER TABLE `tbl_day` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_instrctr
CREATE TABLE IF NOT EXISTS `tbl_instrctr` (
  `instructor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `age` varchar(50) NOT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `load` double NOT NULL DEFAULT '0',
  `fk_cllge` int(11) NOT NULL,
  PRIMARY KEY (`instructor_id`,`fk_cllge`),
  KEY `tbl_instrctr_fk_college` (`fk_cllge`),
  CONSTRAINT `tbl_instrctr_fk_college` FOREIGN KEY (`fk_cllge`) REFERENCES `tbl_cllge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_instrctr: ~21 rows (approximately)
DELETE FROM `tbl_instrctr`;
/*!40000 ALTER TABLE `tbl_instrctr` DISABLE KEYS */;
INSERT INTO `tbl_instrctr` (`instructor_id`, `first_name`, `middle_name`, `last_name`, `birthdate`, `age`, `sex`, `load`, `fk_cllge`) VALUES
	(3, 'Paraluman Maria Fatima', 'B.', 'Pesito', '1985-03-26', '35', 0, 27, 1),
	(4, 'Daryl', 'V.', 'Buen', '1995-11-09', '25', 1, 24, 1),
	(5, 'Maribel', 'T.', 'Tacla', '1989-04-20', '30', 0, 24, 1),
	(6, 'Rosanne', 'S.', 'Agup', '1988-09-10', '32', 0, 27, 1),
	(7, 'Richard', 'C.', 'Arruejo', '1988-08-14', '31', 0, 27, 1),
	(8, 'Honey Girl', 'A.', 'Avo', '1987-07-30', '35', 0, 27, 1),
	(9, 'Peter', 'R.', 'Rabanal', '1976-09-07', '43', 1, 24, 1),
	(10, 'June Leonel', 'M.', 'Ngayaan', '1995-06-14', '24', 1, 24, 1),
	(11, 'Jennyfer', 'D.', 'Alasaas', '1990-01-16', '30', 0, 27, 1),
	(12, 'Noel', 'S.', 'Rafanan', '1997-07-17', '23', 1, 15, 1),
	(13, 'Angelito', 'T.', 'Ramos', '1995-03-26', '25', 1, 24, 1),
	(14, 'Caren Kate', 'V.', 'Quitoriano', '1984-01-03', '36', 0, 24, 1),
	(15, 'Fernandino', 'S.', 'Perilla', '1975-10-30', '45', 1, 24, 1),
	(16, 'Rogelio', 'R.', 'Rabena', '1990-03-27', '30', 1, 24, 1),
	(17, 'Leo Angelou', 'B.', 'Baja', '1995-05-25', '25', 1, 24, 1),
	(18, 'Leilani', 'A.', 'Basa', '1971-07-12', '49', 0, 24, 1),
	(19, 'Harold', 'L.', 'Costales', '1986-10-26', '35', 1, 24, 1),
	(20, 'Mariano JR.', 'T.', 'Romano', '1979-12-28', '40', 1, 24, 1),
	(21, 'Esteban', 'H.', 'Fabro', '1995-03-05', '25', 1, 15, 1),
	(22, 'Joel', 'S.', 'Morales', '1995-02-09', '25', 1, 15, 1),
	(23, 'Bryan', 'S.', 'Lamarca', '1983-02-09', '37', 1, 27, 1);
/*!40000 ALTER TABLE `tbl_instrctr` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_room
CREATE TABLE IF NOT EXISTS `tbl_room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `fk_college` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`room_id`,`fk_college`),
  KEY `tbl_room_fk_college` (`fk_college`),
  CONSTRAINT `tbl_room_fk_college` FOREIGN KEY (`fk_college`) REFERENCES `tbl_cllge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_room: ~11 rows (approximately)
DELETE FROM `tbl_room`;
/*!40000 ALTER TABLE `tbl_room` DISABLE KEYS */;
INSERT INTO `tbl_room` (`room_id`, `description`, `fk_college`) VALUES
	(1, 'CC101', 1),
	(2, 'CC102', 1),
	(3, 'CC104', 1),
	(4, 'CC105', 1),
	(5, 'CC201', 1),
	(6, 'CC202', 1),
	(7, 'CC203', 1),
	(8, 'CC204', 1),
	(9, 'CC205', 1),
	(10, 'CC206', 1),
	(11, 'IAC', 1);
/*!40000 ALTER TABLE `tbl_room` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_section
CREATE TABLE IF NOT EXISTS `tbl_section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(11) DEFAULT '',
  `section` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `fk_course` int(11) NOT NULL,
  `fk_year` int(11) NOT NULL,
  `fk_collge` int(11) NOT NULL,
  PRIMARY KEY (`fk_course`,`fk_year`,`section`,`section_id`) USING BTREE,
  UNIQUE KEY `section_id` (`section_id`),
  KEY `fk_college` (`fk_collge`),
  KEY `tbl_stdnts_fk_course` (`fk_course`),
  KEY `tbl_stdnts_fk_year` (`fk_year`),
  KEY `section` (`section`),
  CONSTRAINT `tbl_stdnts_fk_college` FOREIGN KEY (`fk_collge`) REFERENCES `tbl_cllge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_stdnts_fk_course` FOREIGN KEY (`fk_course`) REFERENCES `tbl_course` (`cource_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_stdnts_fk_year` FOREIGN KEY (`fk_year`) REFERENCES `tbl_year` (`year_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- Dumping data for table sstss_data.tbl_section: ~21 rows (approximately)
DELETE FROM `tbl_section`;
/*!40000 ALTER TABLE `tbl_section` DISABLE KEYS */;
INSERT INTO `tbl_section` (`section_id`, `description`, `section`, `fk_course`, `fk_year`, `fk_collge`) VALUES
	(1, 'BSCS 1', ' ', 1, 1, 1),
	(2, 'BSCS 2', ' ', 1, 2, 1),
	(3, 'BSIT 1 A', 'A', 2, 1, 1),
	(4, 'BSIT 1 B', 'B', 2, 1, 1),
	(5, 'BSIT 1 C', 'C', 2, 1, 1),
	(6, 'BSIT 1 D', 'D', 2, 1, 1),
	(7, 'BSIT 2 A', 'A', 2, 2, 1),
	(8, 'BSIT 2 B', 'B', 2, 2, 1),
	(9, 'BSIT 2 C', 'C', 2, 2, 1),
	(10, 'BSIT 3', '', 2, 3, 1),
	(11, 'BSIT 4 A', 'A', 2, 4, 1),
	(12, 'BSIT 4 B', 'B', 2, 4, 1),
	(13, 'BLIS 1', ' ', 3, 1, 1),
	(14, 'BLIS 2', ' ', 3, 2, 1),
	(15, 'DICT 1 A', 'A', 4, 1, 1),
	(16, 'DICT 1 B', 'B', 4, 1, 1),
	(17, 'DICT 1 C', 'C', 4, 1, 1),
	(18, 'DICT 1 D', 'D', 4, 1, 1),
	(19, 'DICT 2 A', 'A', 4, 2, 1),
	(20, 'DICT 2 B', 'B', 4, 2, 1),
	(21, 'DICT 2 C', 'C', 4, 2, 1);
/*!40000 ALTER TABLE `tbl_section` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_subject
CREATE TABLE IF NOT EXISTS `tbl_subject` (
  `subject_code` varchar(50) NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `unit` double NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_subject: ~127 rows (approximately)
DELETE FROM `tbl_subject`;
/*!40000 ALTER TABLE `tbl_subject` DISABLE KEYS */;
INSERT INTO `tbl_subject` (`subject_code`, `description`, `unit`) VALUES
	('CC101', 'Introduction to Computing', 3),
	('CC102', 'Fundamentals of Programming', 3),
	('CC103', 'Intermediate Programming', 3),
	('CC104', 'Data Structures and Algorithm', 3),
	('CC105', 'Information Management', 3),
	('CC106', 'Application Development and Emerging Technologies', 3),
	('CSA101', 'Web Systems and Technologies', 3),
	('CSA102', 'Introduction to Artificial Intelligence', 3),
	('CSA103', 'Mobile System and Technologies', 3),
	('CSA104', 'Methods of Research in Computing', 3),
	('CSA105', 'Machine Learning', 3),
	('CSA106', 'Data Mining', 3),
	('CSE1', 'CS Elective 1', 3),
	('CSE2', 'CS Elective 2', 3),
	('CSE3', 'CS Elective 3', 3),
	('CSE4', 'CS Elective 4', 3),
	('CSP101', 'Discrete Structures', 3),
	('CSP102', 'Human Computer Interaction & Graphic/Visual Computing', 3),
	('CSP103', 'Architecture and Organization', 3),
	('CSP104', 'Object-Oriented Programming', 3),
	('CSP105', 'Algorithm and Complexity', 3),
	('CSP106', 'Automata and Formal Languages', 3),
	('CSP107', 'Programming Language', 3),
	('CSP108', 'Operating System', 3),
	('CSP109', 'Software Engineering 1', 3),
	('CSP110', 'Software Engineering 2', 3),
	('CSP111', 'Network and Communication', 3),
	('CSP112', 'Practicum', 3),
	('CSP113', 'Information Assurance and Security', 3),
	('CSP114', 'CS Thesis Writing 1', 3),
	('CSP115', 'CS Thesis Writing 2', 3),
	('CSP116', 'Social Issues and Professional Practice', 3),
	('CSS101', 'Installing andConfiguring Computer Systems', 3),
	('CSS102', 'Networking 1 (Setting-up Computer Networks)', 3),
	('CSS103', 'Networking 2 (Setting-up Computer Servers)', 3),
	('CSS104', 'Networking 3 (Maintaining & Repairing Computer Systems & Networks)', 3),
	('CT101', 'Introduction to Computing', 3),
	('CT102', 'Computer Programming 1', 3),
	('CT103', 'Computer Programming 2', 3),
	('CT104', 'Object-Oriented Programming', 3),
	('DB101', 'DBMS 1 (Database Administration)', 3),
	('DB102', 'DBMS 2 (Database Programming)', 3),
	('EdCog1', 'Listening and Speaking Skills', 3),
	('EdCog2', 'Building and Enhancing New Literacies Across the Curriculum', 3),
	('EdCog3', 'Facillitating Learner-Centered Teaching', 3),
	('EdCog4', 'The Teaching Profession', 3),
	('EndCog3', 'Writting Skills', 3),
	('EngCog2', 'Reading Skills', 3),
	('Ethics', 'Ethics', 3),
	('Fil101', 'Kontekstwalisadong Komunkasyon sa Filipino', 3),
	('Fil102', 'Dalumat ng/sa Filipino', 3),
	('Hum101', 'Art Appreciation', 3),
	('I.T.Cog1', 'Multimedia Systems', 3),
	('I.T.Cog2', 'Operating Systems', 3),
	('ICT101', 'Fundamentals of Computing', 3),
	('ICT102', 'Information Processing and Handling in Library and Information Centers', 3),
	('ICT103', 'Digital Libraries and Resources', 3),
	('ICT104', 'Web Technologies in Libraries and Information Centers', 3),
	('ICT105', 'Database Design', 3),
	('ICT106', 'Systems Analysis and Design Libraries and Information Centers', 3),
	('ITA101', 'Object-oriented Programming', 3),
	('ITA102', 'Multimedia (Digital Arts)', 3),
	('ITA103', 'Multimedia (Digital Arts)', 3),
	('ITA104', 'Software Engineering', 3),
	('ITA105', 'Operating Systems', 3),
	('ITA106', 'IT Research Design and Methodology', 3),
	('ITA107', 'ICT Trends, Issues, and Innovations(with seminar  and Field Trips)', 1),
	('ITE1', 'IT Elective 1', 3),
	('ITE2', 'IT Elective 2', 3),
	('ITE3', 'IT Elective 3', 3),
	('ITE4', 'IT Elective 4', 3),
	('ITE5', 'IT Elective 5', 3),
	('ITP102', 'Information Assurance and Security 1', 3),
	('ITP103', 'Information Assurance and Security 2', 3),
	('ITP104', 'Fundamental of Database Systems', 3),
	('ITP105', 'Integrative Programming and Technologies 1', 3),
	('ITP106', 'Discrete Mathematics', 3),
	('ITP107', 'Quatitative Methods(incl. Modeling and Simulation)', 3),
	('ITP108', 'Networking 1', 3),
	('ITP109', 'Networking 2', 3),
	('ITP110', 'Practicum', 6),
	('ITP111', 'Systems Administration and Maintenance', 3),
	('ITP112', 'Systems Integration and Architecture 1', 3),
	('ITP113', 'Social and Professional Issues', 3),
	('ITP114', 'Capstone Project and Research 1', 3),
	('ITP115', 'Capstone Project and Research 2', 3),
	('LibPrc101', 'Practicum 1', 3),
	('LibPrc2', 'Practicum 2', 3),
	('LIS-04', 'Philosophies and Principles of Teaching', 3),
	('LIS-Sp-101', 'School and Academic Librarianship', 3),
	('LIS-Sp-102', 'Special and Public Librarianship', 3),
	('LIS-Sp-103', 'Preservation of Information Resources', 3),
	('LIS-Sp-105', 'Educational Technology', 3),
	('LIS-Sp-106', 'Indigenous Knowledge and Multi-Culturalism', 3),
	('LIS-Sp-107', 'Foreign Language', 3),
	('LIS101', 'Introduction of Library and Information Science', 3),
	('LIS102', 'Collection Management of Information Resources', 3),
	('LIS103', 'Information Resources and Services 1', 3),
	('LIS104', 'Information Sources and Services II', 3),
	('LIS105', 'Organization of Information Sources 1', 3),
	('LIS106', 'Organization of Information Sources II', 3),
	('LIS107', 'Indexing and Abstracting', 3),
	('LIS108', 'Management of Libraries and Information Centers', 3),
	('LIS109', 'Information Literacy', 3),
	('LIS110', 'Library Materials fir Children and Yound Adults', 3),
	('LIS111', 'Archives, Museums and Records Managements', 3),
	('LIS112', 'Research Methods in Library and Information Science', 3),
	('LIS113', 'Thesis Writing', 3),
	('LIS114', 'Seminar in Librarianship (LEL Enhancement)', 3),
	('Math101', 'Mathematics in the Modern World', 3),
	('MR101', 'Graph Theory and Application', 3),
	('NSTP1', 'ROTC/CWTS', 3),
	('NSTP2', 'ROTC/CWTS', 3),
	('Pan101', 'Sinesosyedad/Pelikulang Panlipunan(Sinesos)', 3),
	('Pan102', 'Sosyedad at Literatura(Soslit)', 3),
	('PCom101', 'Purposive Communication', 3),
	('PE101', 'Movement and Enhancement', 2),
	('PE102', 'Fitness Exercise', 2),
	('PE103', 'Dance and Group Exercise', 2),
	('PE104', 'Sports, Outdoor, and Adventure Activities', 2),
	('Rizal', 'The Life, Works, and Writing of Rizal', 3),
	('SocSci101', 'Understanding the Self', 3),
	('SocSci102', 'Reading in the Philippines History', 3),
	('SocSci103', 'The Contemporary World', 3),
	('STS', 'Science, Technology and Society', 3),
	('WEB101', 'Web Programming 1', 3),
	('WEB102', 'Web Programming 2', 3);
/*!40000 ALTER TABLE `tbl_subject` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_time
CREATE TABLE IF NOT EXISTS `tbl_time` (
  `time_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` time NOT NULL DEFAULT '00:00:00',
  PRIMARY KEY (`time_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table sstss_data.tbl_time: ~54 rows (approximately)
DELETE FROM `tbl_time`;
/*!40000 ALTER TABLE `tbl_time` DISABLE KEYS */;
INSERT INTO `tbl_time` (`time_id`, `time`) VALUES
	(1, '07:30:00'),
	(2, '07:59:59'),
	(3, '08:00:00'),
	(4, '08:29:59'),
	(5, '08:30:00'),
	(6, '08:59:59'),
	(7, '09:00:00'),
	(8, '09:29:59'),
	(9, '09:30:00'),
	(10, '09:59:59'),
	(11, '10:00:00'),
	(12, '10:29:59'),
	(13, '10:30:00'),
	(14, '10:59:59'),
	(15, '11:00:00'),
	(16, '11:29:59'),
	(17, '11:30:00'),
	(18, '11:59:59'),
	(19, '12:00:00'),
	(20, '12:29:59'),
	(21, '12:30:00'),
	(22, '12:59:59'),
	(23, '01:00:00'),
	(24, '01:29:59'),
	(25, '01:30:00'),
	(26, '01:59:59'),
	(27, '02:00:00'),
	(28, '02:29:59'),
	(29, '02:30:00'),
	(30, '02:59:59'),
	(31, '03:00:00'),
	(32, '03:29:59'),
	(33, '03:30:00'),
	(34, '03:59:59'),
	(35, '04:00:00'),
	(36, '04:29:59'),
	(37, '04:30:00'),
	(38, '04:59:59'),
	(39, '05:00:00'),
	(40, '05:29:59'),
	(41, '05:30:00'),
	(42, '05:59:59'),
	(43, '05:00:00'),
	(44, '05:29:59'),
	(45, '05:30:00'),
	(46, '05:59:59'),
	(47, '05:00:00'),
	(48, '05:29:59'),
	(49, '05:30:00'),
	(50, '05:59:59'),
	(51, '06:00:00'),
	(52, '06:29:59'),
	(53, '06:30:00'),
	(54, '06:59:59');
/*!40000 ALTER TABLE `tbl_time` ENABLE KEYS */;

-- Dumping structure for table sstss_data.tbl_year
CREATE TABLE IF NOT EXISTS `tbl_year` (
  `year_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_college` int(11) NOT NULL DEFAULT '0',
  `fk_course` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`year_id`,`fk_college`,`fk_course`),
  KEY `tbl_course_fk_college` (`fk_college`),
  KEY `tbl_year_fk_course` (`fk_course`),
  CONSTRAINT `tbl_year_fk_college` FOREIGN KEY (`fk_college`) REFERENCES `tbl_cllge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_year_fk_course` FOREIGN KEY (`fk_course`) REFERENCES `tbl_course` (`cource_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- Dumping data for table sstss_data.tbl_year: ~14 rows (approximately)
DELETE FROM `tbl_year`;
/*!40000 ALTER TABLE `tbl_year` DISABLE KEYS */;
INSERT INTO `tbl_year` (`year_id`, `fk_college`, `fk_course`) VALUES
	(1, 1, 1),
	(1, 1, 2),
	(1, 1, 3),
	(1, 1, 4),
	(2, 1, 1),
	(2, 1, 2),
	(2, 1, 3),
	(2, 1, 4),
	(3, 1, 1),
	(3, 1, 2),
	(3, 1, 3),
	(4, 1, 1),
	(4, 1, 2),
	(4, 1, 3);
/*!40000 ALTER TABLE `tbl_year` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
